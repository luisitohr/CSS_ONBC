#!/bin/bash

# red a escanear
NETWORK="172.22.1.0/24"

# ruta de salida
OUTPUT_DIR="/media/red"

# mostrar fecha y hora actuales para los nombres de los archivos
CURRENT_DATE=$(date +"%Y-%m-%d_%H-%M")

# archivos de salida con la fecha y hora en el nombre
OUTPUT_XML="${OUTPUT_DIR}/scan_${CURRENT_DATE}.xml"
OUTPUT_TXT="${OUTPUT_DIR}/scan_${CURRENT_DATE}.txt"

# escaneo con nmap y resultados en XML y TXT
nmap -sP -oX $OUTPUT_XML -oN $OUTPUT_TXT --script smb-os-discovery,smb-enum-users,smb-enum-shares,smb-system-info $NETWORK

echo "Escaneo completado. Resultados guardados en $OUTPUT_XML y $OUTPUT_TXT"