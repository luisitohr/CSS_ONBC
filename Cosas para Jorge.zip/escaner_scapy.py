from scapy.all import ARP, Ether, srp

def scan_network(ip_range):

    arp = ARP(pdst=ip_range)

    ether = Ether(dst="ff:ff:ff:ff:ff:ff")

    packet = ether/arp


    result = srp(packet, timeout=2, verbose=0)[0]


    devices = []

    for sent, received in result:
        # Añade IP y MAC a la lista
        devices.append({'ip': received.psrc, 'mac': received.hwsrc})

    return devices

# Rango de IPs a escanear 
ip_range = "127.0.0.1/24"
devices = scan_network(ip_range)

# Mostrar los dispositivos encontrados
print("Dispositivos encontrados en la red:")
for device in devices:
    print(f"IP: {device['ip']}, MAC: {device['mac']}")