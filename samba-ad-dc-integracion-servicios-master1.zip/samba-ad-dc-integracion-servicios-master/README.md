This repo is deprecated. Updated content at: [https://github.com/kurosaki1976/samba4-ad-dc-integrated-services/](https://github.com/kurosaki1976/samba4-ad-dc-integrated-services/)
