#!/bin/bash

#Script de Instalacion automatica de Samba4 como PDC.
#Se debe editar el mismo y ajustar las variables de entorno para su adecuado funcionamiento
#Cuando se ejecute por primera vez, tenga en cuenta que al finalizar, el host se reiniciará
#Su uso es "./samba-install install" para la primera vez donde se instalará todo lo necesario
#Luego "./samba-install create" para crear un nuevo dominio usando las variables de entorno. 
#El script tambien creará la zona inversa, pero no agrega ningun valor.



#########################
#####   Variables   #####
#########################


export REALM=ADDC.PRUEBAS.NET
export DOMAIN=PRUEBAS.NET
export DNS_BACKEND=SAMBA_INTERNAL
export DOMAINPASS=Admin123.
export DNSFORWARDER=192.168.35.1
export HOSTIP=192.168.35.2
export REVERSE_RANGE=35.168.192

install()
{
#Instalacion sobre Debian
echo "###############################"
echo "#         Instalando:         #"
echo "###############################"
export DEBIAN_FRONTEND=noninteractive
apt update && apt-get install -y \
     acl \
     attr \
     libpam-krb5 \
     krb5-config \
     krb5-user \
     dnsutils \
     winbind \
     libpam-winbind \
     libnss-winbind \
     samba \
     samba-dsdb-modules \
     samba-vfs-modules 
  
systemctl unmask samba-ad-dc.service
systemctl enable samba-ad-dc.service

}

create()
{

echo "###############################"
echo "#     Variables a usar:       #"
echo "###############################"
echo "REALM=${REALM}"
echo "DOMAIN=${DOMAIN}"
echo "DNS_BACKEND=${DNS_BACKEND}"
echo "DOMAINPASS=${DOMAINPASS}"
echo "DNSFORWARDER=${DNSFORWARDER}"
echo "HOSTIP=${HOSTIP}"
echo "REVERSE_RANGE=${REVERSE_RANGE}"
echo "###############################"



#Provisionamiento (Crear un nuevo Dominio)
if [ -f /etc/samba/smb.conf ]; then
    rm /etc/samba/smb.conf
fi
echo "###############################"
echo "#        Provisionando        #"
echo "###############################"
echo "Ejecutando: samba-tool domain provision --server-role=dc --use-rfc2307 --dns-backend=$DNS_BACKEND --realm=$REALM  --domain=$DOMAIN  --adminpass=$DOMAINPASS"
samba-tool domain provision --server-role=dc --use-rfc2307 --dns-backend=$DNS_BACKEND --realm=$REALM  --domain=$DOMAIN  --adminpass=$DOMAINPASS
    
    
#Configurando Kerberos

echo "###############################"
echo "#   Configurando Kerberos     #"
echo "###############################"

rm /etc/krb5.conf
cp /var/lib/samba/private/krb5.conf /etc/krb5.conf

#Configurando el DNS Resolver
echo "###############################"
echo "#  Configurando DNS RESOLVER  #"
echo "###############################"

echo "search $REALM" >> /etc/resolv.conf
echo "nameserver $HOSTIP" >> /etc/resolv.conf
sed -i "s/dns forwarder = .*/dns forwarder = ${DNSFORWARDER}/g" /etc/samba/smb.conf
reboot
}

reverse()
{
#Configurando la Zona Inversa
echo "###############################"
echo "#  Configurando Zona Inversa  #"
echo "###############################"
echo "Ejecutando: samba-tool dns zonecreate $HOSTIP ${REVERSE_RANGE}.in-addr.arpa -Uadministrator@${DOMAIN} --password=${DOMAINPASS}"
samba-tool dns zonecreate $HOSTIP ${REVERSE_RANGE}.in-addr.arpa -Uadministrator@${DOMAIN} --password=${DOMAINPASS}
}

help()
{
echo "Script de Instalacion automatica de Samba4 como PDC."
echo "Se debe editar el mismo y ajustar las variables de entorno para su adecuado funcionamiento"
echo "Tenga en cuenta que al finalizar de privisionar, el host se reiniciará"
echo "Su uso es ./${0} install para la primera vez donde se instalará todo lo necesario"
echo "Luego ./${0} create para crear un nuevo dominio usando las variables de entorno. "
echo "El script tambien creará la zona inversa, pero no agrega ningun valor."
}


case "$1" in
install)
	install
	;;
create)
    create
	;;
reverse)
    reverse
	;;	
help)
    help
    ;;
*)
	echo $"Usage: $0 {install|create|reverse|help}"
	exit 2
esac
