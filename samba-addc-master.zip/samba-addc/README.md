# Instalacion de Samba4 como PDC en Debian 10


___Suponemos para el tutorial que usted cuenta con un host con apt update && apt upgrade y que tiene acceso a alguna fuente de repositorios___

**Requisitos**

```
1. Host limpio o CT de Proxmox (Debian Buster)
2. Acceso root
3. Saber Leer
```

**Instalacion**

Para la instalacion solo necesitaremos hacer un ajuste antes de comenzar a instalar. Debemos ejecutar el siguiente comando:

```
export DEBIAN_FRONTEND=noninteractive
```

Esto nos va a permitir que al comenzar a instalar, no nos salgan carteles del sistema pidiendo informacion, ya que al final no la vamos a usar.
Ahora si, vamos a instalar todo lo necesario 

```
apt update && apt-get install -y \
     acl \
     attr \
     libpam-krb5 \
     krb5-config \
     krb5-user \
     dnsutils \
     winbind \
     libpam-winbind \
     libnss-winbind \
     samba \
     samba-dsdb-modules \
     samba-vfs-modules \
     mc
```

El paquete mc no es necesario, pero puede ayudar a algunos, asi que lo pongo por si acaso

Ahora vamos a usar algunas variables, lo cual nos va a ayudar a no escribir de mas y facilitar el mantenimiento

```
export REALM=ADDC.PRUEBAS.NET
export DOMAIN=PRUEBAS.NET
export DNS_BACKEND=SAMBA_INTERNAL
export DOMAINPASS=Admin123.
export DNSFORWARDER=192.168.35.1
export HOSTIP=192.168.35.2
export REVERSE_RANGE=35.168.192
```

Veamos algunos detalles: 
El host se llama ADDC. El REALM es el FQDN del host y que va a funcionar como Reino de dominio, seria HOST+DOMINIO\n
DNS_BACKEND es el tipo de DNS que vamos a usar. En este caso, SAMBA_INTERNAL pues provee actualizacion dinamica de registros y reenviar las consultas a otro DNS
DNSFORWARDER es el host DNS que se va a encargar de las consultas DNS fuera del dominio. Puede ser bind9, dnsmasq, winDNS, etc
REVERSE_RANGE es el rango para la zona inversa que se crea

Eliminamos el archivo smb.conf si existe usando

```
rm /etc/samba/smb.conf
```

**Privisionamiento**

Ahora, vamos a provisionar, podemos hacerlo de forma interactiva, pero realmente es mucho mas rapido hacerlo de forma automatica usando las variables que creamos arriba:

```
samba-tool domain provision --server-role=dc --use-rfc2307 --dns-backend=$DNS_BACKEND --realm=$REALM  --domain=$DOMAIN  --adminpass=$DOMAINPASS
rm /etc/krb5.conf
cp /var/lib/samba/private/krb5.conf /etc/krb5.conf
```

Ahora debemos configurar el DNSFORWARDER pues el comando no interactivo no permite el parametro.

```
echo "search $REALM" >> /etc/resolv.conf
echo "nameserver $HOSTIP" >> /etc/resolv.conf
sed -i "s/dns forwarder = .*/dns forwarder = ${DNSFORWARDER}/g" /etc/samba/smb.conf
```

Lo que hicimos fue editar el archivo /etc/resolv.conf y escribir dentro las lineas:
_search PRUEBAS.NET_
_nameserver 192.168.35.2_

Y luego editar el archivo /etc/samba/smb.conf y dentro agregar la IP del DNSFORWARDER.

Ahora hacemos unos cambios en el servicio del samba y reiniciamos

```
systemctl unmask samba-ad-dc.service
systemctl enable samba-ad-dc.service
reboot
```

**Configuracion de la Zona Inversa**

Para configurar la zona inversa debemos ejecutar el siguiente comando:

```
samba-tool dns zonecreate 192.168.35.2 35.168.192.in-addr.arpa -Uadministrator@PRUEBAS.NET --password=Admin123.
```


**Conclusiones**

Con esto, tenemos un Controlador de Dominio muy basico funcionando en nuestra red. Solo queda ir agregando los host de los usuarios al dominio y crear los registros estaticos de los servicios. Los registros A y CNAME que necesitemos.
