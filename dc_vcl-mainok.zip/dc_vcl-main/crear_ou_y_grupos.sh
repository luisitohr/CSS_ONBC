#!/bin/bash

# Variables del dominio
OU_NAME="Dir Prov ONBC VCL"
DOMAIN="vcl.onbc.cu"
DC_PARTS=$(echo $DOMAIN | sed 's/\./,DC=/g')
OU_DN="OU=$OU_NAME,DC=$DC_PARTS"

# Crear la unidad organizativa
echo "Creando la unidad organizativa: $OU_NAME"
samba-tool ou create "$OU_DN"
if [ $? -ne 0 ]; then
  echo "Error al crear la unidad organizativa: $OU_NAME"
  exit 1
fi

# Crear los grupos dentro de la unidad organizativa
GROUPS=("BES" "SC3" "DirProv")
for GROUP in "${GROUPS[@]}"; do
  echo "Creando el grupo: $GROUP"
  samba-tool group add "CN=$GROUP,$OU_DN" --group-scope=Global --group-type=Security
  if [ $? -ne 0 ]; then
    echo "Error al crear el grupo: $GROUP"
    exit 1
  fi
done

echo "Unidad organizativa y grupos creados exitosamente."
